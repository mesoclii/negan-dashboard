import fs from "fs";
import path from "path";

const STORE_PATH = path.join(process.cwd(), "data", "engine-configs.json");

function ensureStore() {
  const dir = path.dirname(STORE_PATH);
  if (!fs.existsSync(dir)) fs.mkdirSync(dir, { recursive: true });
  if (!fs.existsSync(STORE_PATH)) fs.writeFileSync(STORE_PATH, "{}", "utf8");
}

export function readAllConfigs(): Record<string, any> {
  ensureStore();
  const raw = fs.readFileSync(STORE_PATH, "utf8");
  try {
    return JSON.parse(raw || "{}");
  } catch {
    return {};
  }
}

export function readEngineConfig(engineId: string): any {
  const all = readAllConfigs();
  return all[engineId] ?? {};
}

export function writeEngineConfig(engineId: string, config: any) {
  ensureStore();
  const all = readAllConfigs();
  all[engineId] = config ?? {};
  fs.writeFileSync(STORE_PATH, JSON.stringify(all, null, 2), "utf8");
}
