import { PossumTabs } from "@/components/possum/PossumTabs";
import { PossumCard } from "@/components/possum/PossumCard";
import { PossumToggle } from "@/components/possum/PossumToggle";

export default function SecurityOverviewPage() {

  return (
    <div>

      <div className="possum-red possum-glow" style={{
        fontSize: 30,
        fontWeight: 950,
        letterSpacing: "0.22em",
        textTransform: "uppercase",
        marginBottom: 18
      }}>
        Security Command
      </div>

      <PossumTabs
        tabs={[
          {
            key: "engines",
            label: "Engines",
            content: (
              <div style={{ display: "grid", gap: 16 }}>
                <PossumCard title="Security Engine" right={<PossumToggle defaultOn />} />
                <PossumCard title="Account Integrity" right={<PossumToggle defaultOn />} />
                <PossumCard title="Behavioral Drift" right={<PossumToggle defaultOn />} />
              </div>
            )
          },
          {
            key: "containment",
            label: "Containment",
            content: (
              <div style={{ display: "grid", gap: 16 }}>
                <PossumCard title="Lockdown Engine" right={<PossumToggle />} />
                <PossumCard title="Raid Engine" right={<PossumToggle defaultOn />} />
                <PossumCard title="Escalation Engine" right={<PossumToggle defaultOn />} />
              </div>
            )
          },
          {
            key: "intel",
            label: "Intelligence",
            content: (
              <div style={{ display: "grid", gap: 16 }}>
                <PossumCard title="Intelligence Engine" right={<PossumToggle defaultOn />} />
                <PossumCard title="Moderation Data" />
              </div>
            )
          }
        ]}
      />

    </div>
  );
}
