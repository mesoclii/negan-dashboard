import type { NextApiRequest, NextApiResponse } from "next";
import { readEngineConfig, writeEngineConfig } from "@/lib/configStore";

export default function handler(req: NextApiRequest, res: NextApiResponse) {
  const { engineId } = req.query;

  if (!engineId || typeof engineId !== "string") {
    return res.status(400).json({ success: false, error: "Missing engineId" });
  }

  if (req.method === "GET") {
    const config = readEngineConfig(engineId);
    return res.status(200).json({ success: true, engineId, config });
  }

  if (req.method === "POST") {
    try {
      const config = typeof req.body === "string" ? JSON.parse(req.body) : req.body;
      writeEngineConfig(engineId, config);
      return res.status(200).json({ success: true, engineId, config });
    } catch (err: any) {
      return res.status(400).json({ success: false, error: err?.message || "Bad JSON" });
    }
  }

  return res.status(405).json({ success: false, error: "Method not allowed" });
}
