// src/pages/api/engines/index.js
const { discoverEngines } = require("../../../../lib/engineRegistry");

export default function handler(req, res) {
  try {
    const engines = discoverEngines();
    return res.status(200).json({ success: true, engines });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: err?.message || String(err),
    });
  }
}
