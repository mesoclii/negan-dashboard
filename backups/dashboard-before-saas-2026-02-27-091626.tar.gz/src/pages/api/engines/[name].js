// src/pages/api/engines/[name].js
import fs from "fs";
import path from "path";

/**
 * IMPORTANT:
 * - We do NOT use dynamic `require(enginePath)` because Turbopack complains.
 * - This endpoint is for staff/dev inspection only: it returns the raw file text.
 * - No UI/color changes. Pure backend path stability.
 */

const ENGINES_PATH =
  process.env.ENGINES_PATH || path.join(process.cwd(), "engines");

export default function handler(req, res) {
  const { name } = req.query;

  if (!name || typeof name !== "string") {
    return res.status(400).json({ success: false, error: "Missing engine name" });
  }

  try {
    const safeName = name.replace(/[^a-zA-Z0-9._-]/g, "");
    const enginePath = path.join(ENGINES_PATH, `${safeName}.js`);

    if (!fs.existsSync(enginePath)) {
      return res.status(404).json({
        success: false,
        error: `Engine not found: ${safeName}`,
        enginePath,
      });
    }

    const content = fs.readFileSync(enginePath, "utf8");

    return res.status(200).json({
      success: true,
      name: safeName,
      enginePath,
      bytes: Buffer.byteLength(content, "utf8"),
      content,
    });
  } catch (err) {
    return res.status(500).json({
      success: false,
      error: err?.message || String(err),
    });
  }
}
