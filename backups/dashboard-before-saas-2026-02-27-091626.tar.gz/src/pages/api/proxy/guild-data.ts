import type { NextApiRequest, NextApiResponse } from "next";

export default async function handler(
  req: NextApiRequest,
  res: NextApiResponse
) {
  try {
    const guildId = req.query.guildId;

    if (!guildId) {
      return res.status(400).json({
        success: false,
        error: "Missing guildId",
      });
    }

    const response = await fetch(
      `http://127.0.0.1:3001/guild-data?guildId=${guildId}`
    );

    const data = await response.json();

    return res.status(200).json(data);
  } catch (error: any) {
    return res.status(500).json({
      success: false,
      error: error?.message || "Proxy failed",
    });
  }
}
