import { useRouter } from "next/router";
import { useEffect, useMemo, useState } from "react";
import { engineCatalog } from "@/lib/engineCatalog";

type ConfigMap = Record<string, any>;

type GuildData = {
  roles: { id: string; name: string }[];
  channels: { id: string; name: string }[];
};

export default function EngineDetail() {
  const router = useRouter();
  const { engineId } = router.query;

  const engine = useMemo(() => {
    if (!engineId || typeof engineId !== "string") return null;
    return engineCatalog.find((e) => e.engineId === engineId) || null;
  }, [engineId]);

  const [config, setConfig] = useState<ConfigMap>({});
  const [guildData, setGuildData] = useState<GuildData>({
    roles: [],
    channels: [],
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (!engine) return;

    setLoading(true);

    Promise.all([
      fetch(`/api/control/engine-config/${engine.engineId}`).then((r) =>
        r.json()
      ),
      fetch(`/api/bot/guild-data`).then((r) => r.json()),
    ])
      .then(([configRes, guildRes]) => {
        setConfig(configRes?.config || {});
        setGuildData(guildRes || { roles: [], channels: [] });
      })
      .finally(() => setLoading(false));
  }, [engine]);

  if (!engine) return <div style={{ padding: 24 }}>Engine not found</div>;

  function setValue(key: string, value: any) {
    setConfig((prev) => ({ ...prev, [key]: value }));
  }

  async function save() {
    if (!engine) return;

    setSaving(true);

    await fetch(`/api/control/engine-config/${engine.engineId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(config),
    });

    setSaving(false);
  }

  return (
    <div style={{ padding: 24 }}>
      <h1 style={{ fontSize: 28, fontWeight: 900 }}>
        {engine.displayName}
      </h1>

      <div style={{ marginTop: 16, display: "grid", gap: 14 }}>
        {engine.controls.map((control) => {
          const value = config[control.key];

          if (control.type === "role") {
            return (
              <div key={control.key}>
                <label>{control.label}</label>
                <select
                  value={value || ""}
                  onChange={(e) =>
                    setValue(control.key, e.target.value)
                  }
                >
                  <option value="">Select Role</option>
                  {guildData.roles.map((r) => (
                    <option key={r.id} value={r.id}>
                      {r.name}
                    </option>
                  ))}
                </select>
              </div>
            );
          }

          if (control.type === "channel") {
            return (
              <div key={control.key}>
                <label>{control.label}</label>
                <select
                  value={value || ""}
                  onChange={(e) =>
                    setValue(control.key, e.target.value)
                  }
                >
                  <option value="">Select Channel</option>
                  {guildData.channels.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>
            );
          }

          if (control.type === "toggle") {
            return (
              <label key={control.key}>
                <input
                  type="checkbox"
                  checked={!!value}
                  onChange={(e) =>
                    setValue(control.key, e.target.checked)
                  }
                />
                {control.label}
              </label>
            );
          }

          return (
            <div key={control.key}>
              <label>{control.label}</label>
              <input
                type="text"
                value={value || ""}
                onChange={(e) =>
                  setValue(control.key, e.target.value)
                }
              />
            </div>
          );
        })}
      </div>

      <button
        onClick={save}
        disabled={saving}
        style={{
          marginTop: 20,
          padding: "10px 16px",
          borderRadius: 10,
          border: "1px solid rgba(255,0,0,0.4)",
          background: "rgba(255,0,0,0.16)",
          color: "#fff",
          fontWeight: 900,
        }}
      >
        {saving ? "Saving..." : "Save"}
      </button>
    </div>
  );
}
