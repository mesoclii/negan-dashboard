import { PossumCard } from "@/components/possum/PossumCard";
import { PossumToggle } from "@/components/possum/PossumToggle";

export default function VipPage() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>

      <div
        className="possum-red possum-glow"
        style={{
          fontSize: 28,
          fontWeight: 950,
          letterSpacing: "0.22em",
          textTransform: "uppercase",
        }}
      >
        VIP / Access Command
      </div>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
        <span className="possum-pill">Tiers</span>
        <span className="possum-pill">Clearance</span>
        <span className="possum-pill">Role Sync</span>
        <span className="possum-pill">Loyalty</span>
      </div>

      <PossumCard
        title="Tier Engine"
        description="VIP tier assignment & automated tracking"
        right={<PossumToggle label="Active" defaultOn={true} />}
      />

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 16 }}>

        {/* Tier 1 */}
        <PossumCard
          title="Tier 1 — Nitro Booster"
          description="Entry Support Tier • Community Boost"
          right={<PossumToggle label="Active" defaultOn={true} />}
        >
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <span className="possum-pill">XP Boost</span>
            <span className="possum-pill">Store Discount</span>
            <span className="possum-pill">Image Perms</span>
          </div>
        </PossumCard>

        {/* Tier 2 */}
        <PossumCard
          title="Tier 2 — Supporter"
          description="Mid Tier • Enhanced Access"
          right={<PossumToggle label="Active" defaultOn={true} />}
        >
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <span className="possum-pill">XP Boost</span>
            <span className="possum-pill">Store Discount</span>
            <span className="possum-pill">Image Perms</span>
            <span className="possum-pill">Heist Exempt</span>
          </div>
        </PossumCard>

        {/* Tier 3 */}
        <PossumCard
          title="Tier 3 — VIP"
          description="Top Tier • Full System Benefits"
          right={<PossumToggle label="Active" defaultOn={true} />}
        >
          <div style={{ display: "flex", gap: 10, flexWrap: "wrap" }}>
            <span className="possum-pill">XP Boost</span>
            <span className="possum-pill">Store Discount</span>
            <span className="possum-pill">Image Perms</span>
            <span className="possum-pill">Heist Exempt</span>
            <span className="possum-pill">Bonus Rewards</span>
            <span className="possum-pill">Priority Queue</span>
            <span className="possum-pill">Premium Perks</span>
          </div>
        </PossumCard>

      </div>

      <PossumCard
        title="Tier Analytics"
        description="Counts, retention, churn (wire later)"
        right={<span className="possum-pill">View</span>}
      >
        <div className="possum-soft" style={{ letterSpacing: "0.12em", textTransform: "uppercase", fontSize: 12 }}>
          Placeholder until API wiring.
        </div>
      </PossumCard>

    </div>
  );
}
