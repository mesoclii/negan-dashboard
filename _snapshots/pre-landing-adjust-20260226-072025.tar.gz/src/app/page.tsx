export default function Home() {
  const now = new Date();

  const dateLine = now.toLocaleDateString("en-US", {
    weekday: "long",
    month: "long",
    day: "2-digit",
    year: "numeric",
    timeZone: "America/Los_Angeles",
  });

  const timeLine = now.toLocaleTimeString("en-US", {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: true,
    timeZone: "America/Los_Angeles",
    timeZoneName: "short",
  });

  return (
    <div className="possum-bg" style={{ minHeight: "100vh" }}>
      <div
        style={{
          minHeight: "100vh",
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          textAlign: "center",
          padding: "40px 18px",
        }}
      >
        <div
          className="possum-red possum-glow"
          style={{
            fontSize: "72px",
            fontWeight: 950,
            letterSpacing: "0.32em",
            textTransform: "uppercase",
            lineHeight: 1.1,
          }}
        >
          POSSUM
          <br />
          CONTROL
          <br />
          ROOM
        </div>

        <div
          className="possum-red possum-glow-soft"
          style={{
            marginTop: "26px",
            fontSize: "18px",
            letterSpacing: "0.35em",
            textTransform: "uppercase",
            opacity: 0.92,
          }}
        >
          Engine Governance • Security Oversight • System Control
        </div>

        <div style={{ marginTop: "28px", display: "flex", gap: "26px" }}>
          <a
            href="/dashboard"
            className="possum-btn"
            style={{
              display: "inline-block",
              padding: "16px 26px",
              textDecoration: "none",
              fontWeight: 950,
              letterSpacing: "0.28em",
              textTransform: "uppercase",
              color: "#000",
              background: "rgba(255, 26, 26, 0.95)",
            }}
          >
            Enter Dashboard
          </a>

          <a
            href="/dashboard/system-health"
            className="possum-btn"
            style={{
              display: "inline-block",
              padding: "16px 26px",
              textDecoration: "none",
              fontWeight: 950,
              letterSpacing: "0.28em",
              textTransform: "uppercase",
              color: "rgba(255, 80, 80, 0.92)",
              background: "transparent",
            }}
          >
            System Status
          </a>
        </div>

        <div
          className="possum-red"
          style={{
            marginTop: "38px",
            fontSize: "28px",
            letterSpacing: "0.24em",
            textTransform: "uppercase",
            opacity: 0.9,
          }}
        >
          {dateLine}
          <br />
          {timeLine}
        </div>

        <div
          className="possum-soft"
          style={{
            position: "absolute",
            bottom: 18,
            left: 0,
            right: 0,
            textAlign: "center",
            letterSpacing: "0.32em",
            textTransform: "uppercase",
            fontSize: "12px",
            opacity: 0.85,
          }}
        >
          Designed by Meso & Raccoon
        </div>
      </div>
    </div>
  );
}
