import Link from "next/link";
import GlobalSidebar from "@/components/possum/GlobalSidebar";

export default function DashboardLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <div className="possum-bg" style={{ minHeight: "100vh" }}>
      <div style={{ display: "flex", minHeight: "100vh" }}>
        {/* Sidebar */}
        <div style={{ width: 260 }}>
          <GlobalSidebar />
        </div>

        {/* Main */}
        <main style={{ flex: 1 }}>
          <header
            style={{
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              padding: "18px 22px",
              borderBottom: "1px solid rgba(255,0,0,0.25)",
            }}
          >
            <div style={{ fontWeight: 950, letterSpacing: "0.35em", fontSize: 14 }}>
              POSSUM DASHBOARD
            </div>

            <div style={{ display: "flex", gap: 12 }}>
              <div
                style={{
                  padding: "10px 12px",
                  borderRadius: 12,
                  border: "1px solid rgba(255,0,0,0.3)",
                  color: "#ff1a1a",
                  fontWeight: 950,
                  letterSpacing: "0.22em",
                  textTransform: "uppercase",
                  fontSize: 12,
                }}
              >
                SYSTEM ONLINE
              </div>

              <Link
                href="/"
                style={{
                  textDecoration: "none",
                  padding: "10px 12px",
                  borderRadius: 12,
                  border: "1px solid rgba(255,0,0,0.3)",
                  color: "#ff1a1a",
                  fontWeight: 950,
                  letterSpacing: "0.22em",
                  textTransform: "uppercase",
                  fontSize: 12,
                }}
              >
                Exit
              </Link>
            </div>
          </header>

          <div style={{ padding: 22 }}>{children}</div>
        </main>
      </div>
    </div>
  );
}
