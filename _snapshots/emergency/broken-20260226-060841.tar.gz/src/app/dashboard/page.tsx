import { PossumCard } from "@/components/possum/PossumCard";
import { PossumToggle } from "@/components/possum/PossumToggle";

export default function DashboardHome() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 18 }}>
      <div
        className="possum-border"
        style={{
          borderRadius: 18,
          padding: 18,
          background: "rgba(0,0,0,0.55)",
        }}
      >
        <div
          className="possum-red possum-glow"
          style={{
            fontSize: 34,
            fontWeight: 950,
            letterSpacing: "0.22em",
            textTransform: "uppercase",
          }}
        >
          Control Overview
        </div>

        <div
          className="possum-soft"
          style={{
            marginTop: 10,
            letterSpacing: "0.16em",
            textTransform: "uppercase",
            fontSize: 12,
            opacity: 0.92,
            lineHeight: 1.7,
          }}
        >
          Flagship governance interface. Read-only until you choose to wire APIs.
        </div>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
          gap: 16,
        }}
      >
        <PossumCard
          title="System Health"
          description="Uptime • memory • heartbeat • /api/health later"
          right={<PossumToggle label="Active" defaultOn={true} />}
        />

        <PossumCard
          title="Security"
          description="Pre-onboarding • onboarding • verification • lockdown"
          right={
            <a
              href="/dashboard/security"
              className="possum-pill"
              style={{ textDecoration: "none" }}
            >
              Open
            </a>
          }
        />

        <PossumCard
          title="VIP / Access"
          description="tiers • clearance • role sync • loyalty"
          right={
            <a
              href="/dashboard/vip"
              className="possum-pill"
              style={{ textDecoration: "none" }}
            >
              Open
            </a>
          }
        />

        <PossumCard
          title="Games"
          description="rare engine • contracts • crews • events"
          right={
            <a
              href="/dashboard/games"
              className="possum-pill"
              style={{ textDecoration: "none" }}
            >
              Open
            </a>
          }
        />

        <PossumCard
          title="GTA Ops"
          description="heist signup • sessions • limits • force close"
          right={
            <a
              href="/dashboard/heist"
              className="possum-pill"
              style={{ textDecoration: "none" }}
            >
              Open
            </a>
          }
        />

        <PossumCard
          title="Audit"
          description="read-only audit views (later wired to audit bus)"
          right={
            <a
              href="/dashboard/audit"
              className="possum-pill"
              style={{ textDecoration: "none" }}
            >
              Open
            </a>
          }
        />
      </div>
    </div>
  );
}
