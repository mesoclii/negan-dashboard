import { SplitModuleLayout } from "@/components/possum/SplitModuleLayout";
import { PossumCard } from "@/components/possum/PossumCard";

export default function VIPPage() {
  return (
    <SplitModuleLayout
      title="VIP / Access"
      sections={[
        {
          key: "supporter",
          label: "Supporter",
          content: (
            <PossumCard
              title="Supporter Policy"
              description="Configure supporter perks and behavior."
            >
              <div className="possum-soft">
                Behavior controls will be added in Phase 2.
              </div>
            </PossumCard>
          ),
        },
        {
          key: "vip",
          label: "VIP",
          content: (
            <PossumCard
              title="VIP Policy"
              description="Configure VIP tier behavior."
            >
              <div className="possum-soft">
                Behavior controls will be added in Phase 2.
              </div>
            </PossumCard>
          ),
        },
        {
          key: "nitro",
          label: "Nitro Booster",
          content: (
            <PossumCard
              title="Nitro Booster Policy"
              description="Configure booster-based permissions."
            >
              <div className="possum-soft">
                Permission mapping will be added in Phase 2.
              </div>
            </PossumCard>
          ),
        },
      ]}
    />
  );
}
