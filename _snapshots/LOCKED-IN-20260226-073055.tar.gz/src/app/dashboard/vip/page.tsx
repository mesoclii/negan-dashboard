import { PossumTabs } from "@/components/possum/PossumTabs";
import { PossumCard } from "@/components/possum/PossumCard";
import { PossumToggle } from "@/components/possum/PossumToggle";

export default function VipOverviewPage() {
  return (
    <div>
      <div
        className="possum-red possum-glow"
        style={{
          fontSize: 30,
          fontWeight: 950,
          letterSpacing: "0.22em",
          textTransform: "uppercase",
          marginBottom: 18,
        }}
      >
        VIP / Access Command
      </div>

      <PossumTabs
        tabs={[
          {
            key: "tiers",
            label: "Tiers",
            content: (
              <div style={{ display: "grid", gap: 18 }}>
                <PossumCard
                  title="Tier Engine"
                  description="VIP tier assignment & automated tracking"
                  right={<PossumToggle defaultOn />}
                />

                <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))", gap: 16 }}>
                  <PossumCard
                    title="Tier 1 — Supporter"
                    description="Entry VIP tier • limited perks"
                    right={<PossumToggle defaultOn />}
                  >
                    <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 10 }}>
                      <span className="possum-pill">XP Boost</span>
                      <span className="possum-pill">Store Discount</span>
                    </div>
                  </PossumCard>

                  <PossumCard
                    title="Tier 2 — VIP"
                    description="Mid VIP tier • stronger benefits"
                    right={<PossumToggle defaultOn />}
                  >
                    <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 10 }}>
                      <span className="possum-pill">Bonus Rewards</span>
                      <span className="possum-pill">Priority Queue</span>
                    </div>
                  </PossumCard>

                  <PossumCard
                    title="Tier 3 — Elite"
                    description="Top tier • exemptions & power tools"
                    right={<PossumToggle defaultOn />}
                  >
                    <div style={{ marginTop: 12, display: "flex", flexWrap: "wrap", gap: 10 }}>
                      <span className="possum-pill">Heist Exemption</span>
                      <span className="possum-pill">Premium Perks</span>
                    </div>
                  </PossumCard>
                </div>

                <PossumCard
                  title="Tier Analytics"
                  description="Counts, retention, churn (wire later)"
                  right={<a href="#" className="possum-pill" style={{ textDecoration: "none" }}>View</a>}
                >
                  <div className="possum-soft" style={{ fontSize: 12, letterSpacing: "0.14em", textTransform: "uppercase" }}>
                    Placeholder until API wiring.
                  </div>
                </PossumCard>
              </div>
            ),
          },
          {
            key: "clearance",
            label: "Clearance",
            content: (
              <div style={{ display: "grid", gap: 18 }}>
                <PossumCard
                  title="Clearance Levels"
                  description="Owner • Co-Owner • Founders • Admin • Support • VIP"
                />
                <PossumCard
                  title="Command Guard"
                  description="Role-based permission gating (UI only)"
                  right={<PossumToggle defaultOn />}
                />
                <PossumCard
                  title="Rank Preview"
                  description="How staff see levels in /rank (wire later)"
                >
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                    <span className="possum-pill">OWNER</span>
                    <span className="possum-pill">FOUNDERS</span>
                    <span className="possum-pill">ADMIN</span>
                    <span className="possum-pill">SUPPORT</span>
                    <span className="possum-pill">VIP</span>
                  </div>
                </PossumCard>
              </div>
            ),
          },
          {
            key: "rolesync",
            label: "Role Sync",
            content: (
              <div style={{ display: "grid", gap: 18 }}>
                <PossumCard
                  title="Role Sync Engine"
                  description="Keeps VIP/tiers aligned with roles"
                  right={<PossumToggle defaultOn />}
                />
                <PossumCard
                  title="Sync Logs"
                  description="Last sync events (UI placeholder)"
                  right={<a href="#" className="possum-pill" style={{ textDecoration: "none" }}>Open</a>}
                >
                  <div className="possum-soft" style={{ fontSize: 12, letterSpacing: "0.14em", textTransform: "uppercase" }}>
                    No data wired yet.
                  </div>
                </PossumCard>
              </div>
            ),
          },
          {
            key: "loyalty",
            label: "Loyalty",
            content: (
              <div style={{ display: "grid", gap: 18 }}>
                <PossumCard
                  title="Loyalty Engine"
                  description="Membership duration tracking"
                  right={<PossumToggle defaultOn />}
                />
                <PossumCard
                  title="Milestones"
                  description="6mo • 12mo • 24mo • Prestige (UI)"
                >
                  <div style={{ display: "flex", flexWrap: "wrap", gap: 10 }}>
                    <span className="possum-pill">6 MONTHS</span>
                    <span className="possum-pill">12 MONTHS</span>
                    <span className="possum-pill">24 MONTHS</span>
                    <span className="possum-pill">PRESTIGE</span>
                  </div>
                </PossumCard>
                <PossumCard
                  title="Reward Hooks"
                  description="Auto-grant exemptions & perks (UI only)"
                  right={<PossumToggle defaultOn />}
                />
              </div>
            ),
          },
        ]}
      />
    </div>
  );
}
