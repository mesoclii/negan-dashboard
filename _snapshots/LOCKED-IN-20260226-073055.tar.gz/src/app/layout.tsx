import "./globals.css";

export const metadata = {
  title: "Possum Control Room",
  description: "Engine Governance • Security Oversight • System Control",
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}
