import "./globals.css"
import type { ReactNode } from "react"

export const metadata = {
  title: "Possum Control Room",
  description: "Engine Governance • Security Oversight • System Control"
}

export default function RootLayout({
  children,
}: {
  children: ReactNode
}) {
  return (
    <html lang="en">
      <body
        style={{
          backgroundColor: "#000000",
          color: "#ff1a1a",
          margin: 0,
          padding: 0
        }}
      >
        {children}
      </body>
    </html>
  )
}
