import type { ReactNode } from "react"

export default function DashboardLayout({ children }: { children: ReactNode }) {
  return (
    <div className="flex min-h-screen">

      {/* Sidebar */}
      <aside className="w-64 bg-black border-r border-red-900 p-6 flex flex-col">

        <div className="mb-12">
          <h1 className="text-2xl font-extrabold tracking-widest uppercase glow-text">
            NEGAN
          </h1>
          <p className="text-xs text-red-800 tracking-widest mt-2 uppercase">
            Control System
          </p>
        </div>

        <nav className="flex flex-col space-y-6 text-sm tracking-wide uppercase">
          <span className="hover:text-red-400 cursor-pointer transition">Dashboard</span>
          <span className="hover:text-red-400 cursor-pointer transition">System Health</span>
          <span className="hover:text-red-400 cursor-pointer transition">Engines</span>
          <span className="hover:text-red-400 cursor-pointer transition">VIP</span>
          <span className="hover:text-red-400 cursor-pointer transition">Security</span>
          <span className="hover:text-red-400 cursor-pointer transition">Audit Logs</span>
        </nav>

        <div className="mt-auto text-xs text-red-800 tracking-widest uppercase">
          Designed by Meso & Raccoon
        </div>

      </aside>

      {/* Main Panel */}
      <div className="flex-1 flex flex-col">

        <header className="h-16 border-b border-red-900 flex items-center justify-between px-8">
          <div className="text-lg font-bold tracking-widest uppercase">
            NEGAN CONTROL
          </div>

          <div className="text-sm text-red-800 tracking-wide">
            System Online
          </div>
        </header>

        <main className="flex-1 p-10 bg-black">
          {children}
        </main>

      </div>

    </div>
  )
}
