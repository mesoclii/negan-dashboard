"use client"

import Link from "next/link"
import { useEffect, useState } from "react"

export default function Home() {
  const [time, setTime] = useState("")
  const [date, setDate] = useState("")

  useEffect(() => {
    const updateClock = () => {
      const now = new Date()

      const timeFormatter = new Intl.DateTimeFormat("en-US", {
        hour: "2-digit",
        minute: "2-digit",
        second: "2-digit",
        hour12: true,
        timeZone: "America/Los_Angeles",
        timeZoneName: "short",
      })

      const dateFormatter = new Intl.DateTimeFormat("en-US", {
        weekday: "long",
        year: "numeric",
        month: "long",
        day: "numeric",
        timeZone: "America/Los_Angeles",
      })

      setTime(timeFormatter.format(now))
      setDate(dateFormatter.format(now))
    }

    updateClock()
    const interval = setInterval(updateClock, 1000)
    return () => clearInterval(interval)
  }, [])

  const neon = {
    color: "#ff1a1a",
    textShadow:
      "0 0 25px rgba(255,0,0,1), 0 0 80px rgba(255,0,0,0.9), 0 0 160px rgba(255,0,0,0.5)",
  }

  return (
    <main className="min-h-screen bg-black flex flex-col justify-between px-8">

      {/* TOP TITLE */}
      <div className="pt-28 text-center">
        <h1
          className="font-extrabold uppercase tracking-[0.35em]"
          style={{
            ...neon,
            fontSize: "clamp(90px, 11vw, 170px)",
          }}
        >
          POSSUM CONTROL ROOM
        </h1>
      </div>

      {/* CENTER */}
      <div className="flex flex-col items-center text-center">

        <p
          className="uppercase tracking-[0.30em] mb-28"
          style={{
            ...neon,
            fontSize: "clamp(28px, 3vw, 42px)",
          }}
        >
          Engine Governance • Security Oversight • System Control
        </p>

        {/* BUTTON ROW — PROPERLY SEPARATED */}
        <div className="flex justify-center items-center">

          <Link
            href="/workarea"
            className="px-20 py-8 text-3xl font-bold uppercase tracking-[0.25em] rounded-md transition"
            style={{
              background: "#ff1a1a",
              color: "#000",
              boxShadow:
                "0 0 60px rgba(255,0,0,0.9), 0 0 120px rgba(255,0,0,0.6)",
              marginRight: "120px"
            }}
          >
            ENTER CONTROL ROOM
          </Link>

          <a
            href="/api/health"
            target="_blank"
            rel="noreferrer"
            className="px-20 py-8 text-3xl font-bold uppercase tracking-[0.25em] border-2 border-red-600 rounded-md transition"
            style={{
              ...neon,
              boxShadow: "0 0 50px rgba(255,0,0,0.8)",
            }}
          >
            SYSTEM STATUS
          </a>

        </div>

      </div>

      {/* BOTTOM */}
      <div className="pb-20 text-center">

        <div
          style={{
            ...neon,
            fontSize: "clamp(34px, 3vw, 50px)",
            letterSpacing: "0.25em",
          }}
        >
          {date}
          <div className="mt-4 font-bold">
            {time}
          </div>
        </div>

        <div
          className="uppercase mt-12"
          style={{
            ...neon,
            fontSize: "clamp(24px, 2vw, 32px)",
            letterSpacing: "0.45em",
          }}
        >
          DESIGNED BY MESO & RACCOON
        </div>

      </div>

    </main>
  )
}
